const help = (prefix) => {
	return `
「 *BOT MARLON WAR* 」

◪ *INFO*
  ❏ Prefixo: 「  ${prefix}  」
  ❏ Criador: MARLON
◪ *SOBRE* 
  │
  ├─ ❏ ${prefix}instagram : OFF

  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}grupo whatsapp : https://chat.whatsapp.com/GNRsojn0GVrB3Ic1ljgM1G
  ├─ ❏ ${prefix}DONO wa.me/5511989677033
  └─ ❏ ${prefix}telegram : OFF

◪ *MÍDIA* 
  │
  ├─ ❏ ${prefix}sticker        ☆  converter imagem em figurinhas

  ├─ ❏ ${prefix}stickergif   ☆ converter videos curtos  ou gif em stickers

  ├─ ❏ ${prefix}toimg          ☆ converter adesivo em imagem 
  ├─ ❏ ${prefix}tomp3
  ├─ ❏ ${prefix}snowwrite
  ├─ ❏ ${prefix}3dtext
  ├─ ❏ ${prefix}neonlogo
  ├─ ❏ ${prefix}neonlogo2
  ├─ ❏ ${prefix}lionlogo
  ├─ ❏ ${prefix}jokerlogo
  ├─ ❏ ${prefix}shadow
  ├─ ❏ ${prefix}burnpaper
  ├─ ❏ ${prefix}coffee
  ├─ ❏ ${prefix}lovepaper
  ├─ ❏ ${prefix}woodblock
  ├─ ❏ ${prefix}qowheart
  ├─ ❏ ${prefix}mutgrass
  ├─ ❏ ${prefix}undergocean
  ├─ ❏ ${prefix}woodenboards
  ├─ ❏ ${prefix}wolfmetal
  ├─ ❏ ${prefix}metalictglow
  ├─ ❏ ${prefix}8bit
  ├─ ❏ ${prefix}harrypotter
  ├─ ❏ ${prefix}pubglogo
  └─ ❏ ${prefix}quotemaker

◪ *MEIOS DE COMUNICAÇÃO*
  │
  ├─ ❏ ${prefix}trendtwit
  ├─ ❏ ${prefix}randomkpop
  └─ ❏ ${prefix}ytsearch    ☆ procurar videos no youtube 
  
◪ *EDUCAÇÃO*
  │
  ├─ ❏ ${prefix}wiki
  ├─ ❏ ${prefix}wikien
  ├─ ❏ ${prefix}nulis
  ├─ ❏ ${prefix}quotes
  ├─ ❏ ${prefix}quotes2
  └─ ❏ ${prefix}artinama

◪ *MAGIC SHELL*
  │
  ├─ ❏ ${prefix}apakah
  ├─ ❏ ${prefix}kapankah
  ├─ ❏ ${prefix}rate
  └─ ❏ ${prefix}bisakah

◪ *DOWNLOADS*

  ├─ ❏ ${prefix}pinterest
  ├─ ❏ ${prefix}ytmp4 😳 baixa videos youTube
  ├─ ❏ ${prefix}tiktok
  └─ ❏ ${prefix}joox

◪ *MEME*
  │
  ├─ ❏ ${prefix}meme
  └─ ❏ ${prefix}memeindo

◪ *GRUPO*
  │
  ├─ ❏ ${prefix}opengc
  ├─ ❏ ${prefix}closegc
  ├─ ❏ ${prefix}promote
  ├─ ❏ ${prefix}demote
  ├─ ❏ ${prefix}tagall
  ├─ ❏ ${prefix}tagall2
  ├─ ❏ ${prefix}tagall3
  ├─ ❏ ${prefix}tagall4
  ├─ ❏ ${prefix}tagall5
  ├─ ❏ ${prefix}add
  ├─ ❏ ${prefix}kick
  ├─ ❏ ${prefix}listadmins
  ├─ ❏ ${prefix}linkgroup
  ├─ ❏ ${prefix}leave
  ├─ ❏ ${prefix}welcome
  ├─ ❏ ${prefix}nsfw
  ├─ ❏ ${prefix}leveling
  ├─ ❏ ${prefix}level
  ├─ ❏ ${prefix}delete
  └─ ❏ ${prefix}ownergroup
          ${prefix}criador
◪ *SONS*
  │
  ├─ ❏ ${prefix}play  .play comando prs baixa musica 😳 .play mais nome da musica
  └─ ❏ ${prefix}tts
◪ *MUSICA*
  │
  ├─ ❏ ${prefix}lirik
  └─ ❏ ${prefix}chord
◪ *ISLAM*
  │
  └─ ❏ ${prefix}quran

◪ *STALK*
  │
  ├─ ❏ ${prefix}tiktokstalk
  └─ ❏ ${prefix}igstalk

◪ *ANIME*
  │
  ├─ ❏ ${prefix}neonime
  ├─ ❏ ${prefix}pokemon
  ├─ ❏ ${prefix}loli
  ├─ ❏ ${prefix}waifu
  ├─ ❏ ${prefix}randomanime
  ├─ ❏ ${prefix}husbu
  ├─ ❏ ${prefix}husbu2
  ├─ ❏ ${prefix}wait
  └─ ❏ ${prefix}nekonime

◪ *18+*  pornô anime
  |
  ├─ ❏ ${prefix}randomhentai  ☆ porno hentai
  ├─ ❏ ${prefix}nsfwtrap           ☆ erro
  └─ ❏ ${prefix}nsfwneko         ☆ porno neko

◪ *DIVERSÃO*
  │
  ├─ ❏ ${prefix}alay
  ├─ ❏ ${prefix}gantengcek
  ├─ ❏ ${prefix}watak
  ├─ ❏ ${prefix}hobby
  ├─ ❏ ${prefix}game
  ├─ ❏ ${prefix}bucin
  ├─ ❏ ${prefix}trust
  ├─ ❏ ${prefix}dare
  └─ ❏ ${prefix}simi

◪ *INFORMAÇÕES*
  │
  ├─ ❏ ${prefix}bahasa  ☆ lista dos codigos dos paises
  ├─ ❏ ${prefix}kodenegara ☆ lista de todos paises do mundo 
  ├─ ❏ ${prefix}kbbi
  ├─ ❏ ${prefix}fakta
  ├─ ❏ ${prefix}infocuaca
  ├─ ❏ ${prefix}infogempa
  ├─ ❏ ${prefix}jadwaltvnow
  └─ ❏ ${prefix}covid

◪ *SOMENTE DONO DO BOT*
  │
  ├─ ❏ ${prefix}setprefix
  ├─ ❏ ${prefix}block
  ├─ ❏ ${prefix}bc
  ├─ ❏ ${prefix}bcgc     ☆ comando inativo
  ├─ ❏ ${prefix}clone    ☆ o bot usara a foto dd perfil do contato marcado 
  └─ ❏ ${prefix}clearall ☆ limpar o chat 
  
◪ *OUTROS*
  │
  ├─ ❏ ${prefix}send      ☆ SPAM 
  ├─ ❏ ${prefix}wame    ☆  pegar o link do teu NUMERO
  ├─ ❏ ${prefix}virtex     ☆ comando pra enviar trava ( se usar o bot te bloquea )
  ├─ ❏ ${prefix}exe
  ├─ ❏ ${prefix}qrcode   ☆ QR code do bot
  ├─ ❏ ${prefix}afk
  ├─ ❏ ${prefix}timer
  ├─ ❏ ${prefix}fml
  └─ ❏ ${prefix}fml2

◪ *🇺🇲MARLON🇺🇲*
`
}

exports.help = help
